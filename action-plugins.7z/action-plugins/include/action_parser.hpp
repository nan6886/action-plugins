#pragma once

#include <string>
#include <unordered_map>
#include <nlohmann/json.hpp>

namespace action_plugins {

class ActionParser {
public:
    struct Input {
        std::string type;
        std::string value;
        std::string goal;
        bool hidden = false;
    };

    struct Action {
        std::string name;
        std::unordered_map<std::string, Input> inputs;
        std::string composeUrlGoal;
        std::vector<std::string> composeUrlParams;
        std::string outputName;
        std::string outputType;
        std::string validateGoal;
        std::string validateValue;
    };

    static Action parse(const std::string& json_content);
    static std::string evaluateExpression(const std::string& expr, const std::unordered_map<std::string, std::string>& context);

private:
    static Input parseInput(const nlohmann::json& json);
};

} // namespace action_plugins 