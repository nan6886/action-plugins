#pragma once

#include "action_parser.hpp"
#include "goal_manager.hpp"
#include <unordered_map>

namespace action_plugins {

class ActionExecutor {
public:
    ActionExecutor(const ActionParser::Action& action);

    std::string execute(const std::unordered_map<std::string, std::string>& input_params);

private:
    ActionParser::Action action_;
    std::unordered_map<std::string, std::string> context_;

    void validateInputs();
    std::string composeUrl();
    void validateOutput(const std::string& output);
};

} // namespace action_plugins 