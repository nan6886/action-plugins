#pragma once

#include <string>
#include <functional>
#include <unordered_map>
#include <memory>

namespace action_plugins {

class GoalManager {
public:
    using GoalFunction = std::function<std::string(const std::vector<std::string>&)>;

    static GoalManager& getInstance();

    void registerGoal(const std::string& name, GoalFunction func);
    std::string executeGoal(const std::string& name, const std::vector<std::string>& params);

private:
    GoalManager() = default;
    std::unordered_map<std::string, GoalFunction> goals_;
};

} // namespace action_plugins 