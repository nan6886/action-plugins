#include "action_executor.hpp"
#include <stdexcept>

namespace action_plugins {

ActionExecutor::ActionExecutor(const ActionParser::Action& action)
    : action_(action) {}

std::string ActionExecutor::execute(const std::unordered_map<std::string, std::string>& input_params) {
    // 初始化上下文
    context_ = input_params;
    
    // 验证输入
    validateInputs();
    
    // 执行composeUrl
    std::string result = composeUrl();
    
    // 验证输出
    validateOutput(result);
    
    return result;
}

void ActionExecutor::validateInputs() {
    for (const auto& [name, input] : action_.inputs) {
        if (!input.goal.empty()) {
            std::string evaluated_value = ActionParser::evaluateExpression(input.value, context_);
            std::vector<std::string> params = {evaluated_value};
            GoalManager::getInstance().executeGoal(input.goal, params);
        }
    }
}

std::string ActionExecutor::composeUrl() {
    std::vector<std::string> params;
    for (const auto& param : action_.composeUrlParams) {
        params.push_back(ActionParser::evaluateExpression(param, context_));
    }
    return GoalManager::getInstance().executeGoal(action_.composeUrlGoal, params);
}

void ActionExecutor::validateOutput(const std::string& output) {
    if (!action_.validateGoal.empty()) {
        std::string evaluated_value = ActionParser::evaluateExpression(action_.validateValue, context_);
        std::vector<std::string> params = {evaluated_value};
        GoalManager::getInstance().executeGoal(action_.validateGoal, params);
    }
}

} // namespace action_plugins 