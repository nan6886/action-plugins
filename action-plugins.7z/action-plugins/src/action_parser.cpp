#include "action_parser.hpp"
#include <regex>

namespace action_plugins {

ActionParser::Action ActionParser::parse(const std::string& json_content) {
    auto json = nlohmann::json::parse(json_content);
    Action action;
    
    action.name = json["name"];
    
    // 解析inputs
    for (const auto& [key, value] : json["inputs"].items()) {
        action.inputs[key] = parseInput(value);
    }
    
    // 解析composeUrl
    action.composeUrlGoal = json["composeUrl"]["goal"];
    for (const auto& param : json["composeUrl"]["value"]) {
        action.composeUrlParams.push_back(param);
    }
    
    // 解析output
    action.outputName = json["output"]["name"];
    action.outputType = json["output"]["type"];
    
    // 解析validate
    action.validateGoal = json["validate"]["goal"];
    action.validateValue = json["validate"]["value"];
    
    return action;
}

ActionParser::Input ActionParser::parseInput(const nlohmann::json& json) {
    Input input;
    input.type = json["type"];
    input.value = json["value"];
    
    if (json.contains("goal")) {
        input.goal = json["goal"];
    }
    
    if (json.contains("hidden")) {
        input.hidden = json["hidden"];
    }
    
    return input;
}

std::string ActionParser::evaluateExpression(const std::string& expr, 
    const std::unordered_map<std::string, std::string>& context) {
    
    std::string result = expr;
    
    // 处理$expr{}表达式
    std::regex expr_pattern(R"(\$expr\{([^}]+)\})");
    std::smatch expr_matches;
    while (std::regex_search(result, expr_matches, expr_pattern)) {
        std::string param_name = expr_matches[1];
        if (context.count(param_name) > 0) {
            result = std::regex_replace(result, expr_pattern, context.at(param_name));
        }
    }
    
    // 处理${}表达式
    std::regex var_pattern(R"(\$\{([^}]+)\})");
    std::smatch var_matches;
    while (std::regex_search(result, var_matches, var_pattern)) {
        std::string var_name = var_matches[1];
        if (context.count(var_name) > 0) {
            result = std::regex_replace(result, var_pattern, context.at(var_name));
        }
    }
    
    return result;
}

} // namespace action_plugins 