#include "action_parser.hpp"
#include "action_executor.hpp"
#include "goal_manager.hpp"
#include <fstream>
#include <iostream>

// 示例Goal函数实现
std::string validateScreenPosition(const std::vector<std::string>& params) {
    // 实现屏幕位置验证逻辑
    return "valid";
}

std::string isMultiView(const std::vector<std::string>& params) {
    // 实现多视图检查逻辑
    return "true";
}

std::string composeMultiViewFullScreenUrl(const std::vector<std::string>& params) {
    // 实现URL组合逻辑
    return "http://example.com/multiview?position=" + params[0] + "&isMultiView=" + params[1];
}

std::string validateMultiViewFullScreenResult(const std::vector<std::string>& params) {
    // 实现结果验证逻辑
    return "valid";
}

int main() {
    try {
        // 注册Goal函数
        auto& goal_manager = action_plugins::GoalManager::getInstance();
        goal_manager.registerGoal("ValidateScreenPosition", validateScreenPosition);
        goal_manager.registerGoal("IsMultiView", isMultiView);
        goal_manager.registerGoal("ComposeMultiViewFullScreenUrl", composeMultiViewFullScreenUrl);
        goal_manager.registerGoal("ValidateMultiViewFullScreenResult", validateMultiViewFullScreenResult);

        // 读取action文件
        std::ifstream file("SetMultiViewFullScreen.action");
        std::string content((std::istreambuf_iterator<char>(file)),
                           std::istreambuf_iterator<char>());

        // 解析action
        auto action = action_plugins::ActionParser::parse(content);

        // 准备输入参数
        std::unordered_map<std::string, std::string> input_params = {
            {"screenPosition", "top"},
            {"isMultiView", "true"}
        };

        // 执行action
        action_plugins::ActionExecutor executor(action);
        std::string result = executor.execute(input_params);

        std::cout << "Action execution result: " << result << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
} 