#include "goal_manager.hpp"
#include <stdexcept>

namespace action_plugins {

GoalManager& GoalManager::getInstance() {
    static GoalManager instance;
    return instance;
}

void GoalManager::registerGoal(const std::string& name, GoalFunction func) {
    goals_[name] = std::move(func);
}

std::string GoalManager::executeGoal(const std::string& name, const std::vector<std::string>& params) {
    auto it = goals_.find(name);
    if (it == goals_.end()) {
        throw std::runtime_error("Goal not found: " + name);
    }
    return it->second(params);
}

} // namespace action_plugins 